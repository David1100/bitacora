
export default function Home() {
  return (
    <main className="flex justify-center items-center min-h-screen">
      <div className="bg-slate-500 w-80 rounded-lg flex justify-center">
        <div className="col-span-1">
          <h1>Hola mundo mundial</h1>
        </div>
      </div>
    </main>
  );
}
